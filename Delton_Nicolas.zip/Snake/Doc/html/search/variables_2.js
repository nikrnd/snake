var searchData=
[
  ['mappa_0',['mappa',['../main_8c.html#a483f02126e42c02d07c9d3e182e6c1c4',1,'main.c']]]
];
