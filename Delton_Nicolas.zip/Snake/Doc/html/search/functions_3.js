var searchData=
[
  ['main_0',['main',['../main_8c.html#ac0f2228420376f4db7e1274f2b41667c',1,'main.c']]],
  ['mappe_1',['mappe',['../main_8c.html#a826a4687f5d130d7df17a276c37bacb6',1,'main.c']]],
  ['moneta_2',['moneta',['../main_8c.html#abac8ff8ab53b73d163ff7d9aa4b794d9',1,'main.c']]]
];
