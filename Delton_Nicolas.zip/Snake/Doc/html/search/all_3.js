var searchData=
[
  ['imprevisto_0',['imprevisto',['../main_8c.html#a43ded42ef154113cee678ad450dc8d6c',1,'main.c']]]
];
