var searchData=
[
  ['r_0',['r',['../main_8c.html#acab531abaa74a7e664e3986f2522b33a',1,'main.c']]]
];
