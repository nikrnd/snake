var searchData=
[
  ['c_0',['c',['../main_8c.html#a4e1e0e72dd773439e333c84dd762a9c3',1,'main.c']]],
  ['conta_5fpassi_1',['conta_passi',['../main_8c.html#a22fe1178cb32536d40375b612ef208b4',1,'main.c']]]
];
