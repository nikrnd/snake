var searchData=
[
  ['verifica_5fcella_0',['verifica_cella',['../main_8c.html#a837bfed1a0316eb3a669ac50e245e2ba',1,'main.c']]]
];
