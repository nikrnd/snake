var searchData=
[
  ['trapani_0',['trapani',['../main_8c.html#a627f5fa9abe658322c368f91a2e4c9da',1,'main.c']]],
  ['trapano_1',['trapano',['../main_8c.html#a8a17eaf7b0ad34c2fc9a949267b55c33',1,'main.c']]]
];
