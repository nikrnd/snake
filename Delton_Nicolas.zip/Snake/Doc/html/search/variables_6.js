var searchData=
[
  ['trapani_0',['trapani',['../main_8c.html#a627f5fa9abe658322c368f91a2e4c9da',1,'main.c']]]
];
