var searchData=
[
  ['genera_5felementi_0',['genera_elementi',['../main_8c.html#a6b9c495032b805d4fc4a269d97afbcb9',1,'main.c']]],
  ['get_5fmove_1',['get_move',['../main_8c.html#aa85dec691519cc95af98960f94427a43',1,'main.c']]]
];
