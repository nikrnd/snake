var searchData=
[
  ['usa_5ftrapano_0',['usa_trapano',['../main_8c.html#ada1ea3f55a417f16eaf4f2326d32c5d8',1,'main.c']]]
];
