var searchData=
[
  ['salva_5fpasso_0',['salva_passo',['../main_8c.html#a5673a0da654a7b9e17876ac9ee518e1e',1,'main.c']]],
  ['sequenza_1',['sequenza',['../main_8c.html#af3696e4fbbe2016b68cba2fca3fa84f0',1,'main.c']]],
  ['stampa_5fmappa_2',['stampa_mappa',['../main_8c.html#a8a54f1a452532f4c0420c8b2b4bcfa23',1,'main.c']]]
];
