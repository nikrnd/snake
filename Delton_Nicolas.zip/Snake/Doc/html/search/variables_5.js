var searchData=
[
  ['sequenza_0',['sequenza',['../main_8c.html#af3696e4fbbe2016b68cba2fca3fa84f0',1,'main.c']]]
];
