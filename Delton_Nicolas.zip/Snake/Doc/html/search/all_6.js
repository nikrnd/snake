var searchData=
[
  ['punteggio_0',['punteggio',['../main_8c.html#a3ae710065269244fe448465525fd9c4d',1,'main.c']]]
];
